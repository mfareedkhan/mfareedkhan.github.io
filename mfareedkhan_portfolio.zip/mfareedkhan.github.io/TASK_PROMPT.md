# TASK_PROMPT — paste this to Claude Code

Copy the text between the lines and give it to Claude Code. Read `CLAUDE.md` in this
folder first — it has all the rules and values you need.

------------------------------------------------------------------------------
Please read `CLAUDE.md` in this repository/folder fully before doing anything; it is the
source of truth for this task, including strict accuracy guardrails you must not violate.

I want to deploy my al-folio portfolio site live on GitHub Pages at
https://mfareedkhan.github.io (free user site; no custom domain). All the written content
is already prepared in this folder — do not rewrite it or change any factual claim.

Do the following, and pause to explain anything you need me to click on the GitHub website:

1. Ensure the al-folio template files are in place, then add/overwrite these provided
   content files into their correct al-folio locations exactly as given:
   _pages/*.md, _bibliography/papers.bib, _data/cv.yml, _news/*.md, _projects/*.md,
   and the two PDFs under assets/pdf/. Keep the template's existing
   assets/img/prof_pic.jpg placeholder.

2. Edit `_config.yml` IN PLACE (do not replace the whole file) to set exactly the values
   listed under "Exact _config.yml values to set" in CLAUDE.md — especially
   url: https://mfareedkhan.github.io and an EMPTY baseurl.

3. Commit and push. Make sure the GitHub Actions build succeeds and GitHub Pages is
   serving from the gh-pages branch. If the site 404s or the build fails, diagnose and
   fix it (the usual cause is a wrong url/baseurl).

4. Verify against the "Definition of done" in CLAUDE.md: all 8 nav pages render;
   publications are grouped by status with my name in bold; both PDFs download from the
   CV page.

Tell me clearly whenever you need me to (a) create the repository, or (b) toggle a
GitHub setting like Pages or workflow permissions — I'll do those clicks. Otherwise,
proceed and keep me posted.
------------------------------------------------------------------------------

## Note on the two Claude Code versions
- **Claude Code on the web (claude.ai/code):** the repo must already exist first. So on the
  GitHub website, click "Use this template" on https://github.com/alshedivat/al-folio and
  create a repo named `mfareedkhan.github.io` (Public). Also commit these provided files
  into that repo (or paste this folder's files) so Claude Code can see them. Then point
  Claude Code at that repo and paste the prompt above.
- **Claude Code in the terminal/desktop:** it can create the repo for you with the GitHub
  CLI. Put this whole folder's contents where it can access them, then paste the prompt
  above and let it drive.
