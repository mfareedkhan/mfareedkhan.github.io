# START HERE — Muhammad Fareed portfolio (al-folio) content package

This package contains the **content files** for your al-folio website, filled with your
real information from your Master Profile and CV. You will drop these into the repository
you create from the al-folio template (I'll guide you step by step in chat).

## What's inside `mfareedkhan.github.io/`
```
_pages/
  about.md          → Home (landing: photo, positioning, selected papers, news)
  research.md       → Research (statement, areas, thesis CXRG-SVLM with metrics)
  publications.md   → Publications (grouped: Published / Under review / In preparation)
  projects.md       → Projects (card grid)
  cv.md             → CV / Résumé (renders the CV data + both PDF downloads)
  about_me.md       → About (journey, teaching, certifications)
  contact.md        → Contact (links, availability, ORCID placeholder)
_bibliography/
  papers.bib        → your 4 publications (drives Publications + Home selected papers)
_data/
  cv.yml            → full CV content (rendered on the CV page)
_news/              → 7 news items (2 have PROVISIONAL dates — see flags below)
_projects/          → RU-SLM, TS-SLM, Multilingual Sentiment (3 project cards)
assets/pdf/
  muhammad_fareed_cv.pdf      → your existing academic CV (downloadable)
  muhammad_fareed_resume.pdf  → NEW 1-page industry résumé I generated for you
```

## Helper files (do NOT upload these to GitHub — they're just for you)
- `CONFIG_CHANGES.md` — the exact `_config.yml` settings to change.
- `START_HERE.md` — this file.

## Your profile photo
The al-folio template already includes a placeholder image at
`assets/img/prof_pic.jpg`. When you have your professional headshot, you'll simply
replace that file (same name) — the Home page already points to it. Nothing to build now.

## Accuracy guardrails already applied (per your structure file)
- Dean's award = "Dean's Honor List (Certificate of Merit Achievement), Spring 2024" —
  **no "CGPA 4.0/4.0" attached to the award**; the 4.0 sits with Education / batch topper.
- "Batch topper / first position" everywhere — **no gold medal claimed**.
- LSTM review = **"in preparation"**, not under review; target Frontiers.
- First Division labels are paired with the percentage (BS 67.45%, B.Ed. 70.97%).
- Publication statuses: 1 published (first author) + 1 under review (first author, thesis)
  + 1 under review (co-author) + 1 in preparation (first author).

## FLAGS — please confirm these (I did not invent facts)
1. **Two news items have provisional dates** (marked with a comment in the file):
   - `_news/2025-09-01-frontiers-published.md` — actual **publication date** of the
     Frontiers paper?
   - `_news/2026-01-10-cxrg-submitted.md` — actual **submission date** of CXRG-SVLM to
     Scientific Reports?
   Give me the real dates and I'll correct them (or we can remove the dates).
2. **Publication month for the Frontiers paper** is not in your documents — same as above.
3. **Blog** is intentionally empty for now (you'll add posts later).
4. **ORCID** left as a placeholder until you create one.
