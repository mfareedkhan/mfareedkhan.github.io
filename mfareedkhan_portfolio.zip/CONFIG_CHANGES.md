# _config.yml — settings to change

**Do NOT replace the whole `_config.yml` file.** Your al-folio template ships with a
long config that contains build machinery. You only need to change the handful of
settings below. When we reach that step, I'll walk you through editing them one at a
time in your browser. This file is just the reference for what those values are.

Find each setting (they already exist in the template's `_config.yml`) and set it to
the value shown. Settings are `key: value` pairs.

## Identity & site basics
```yaml
title: Muhammad Fareed          # navbar brand + browser-tab text
first_name: Muhammad
middle_name:                    # leave empty
last_name: Fareed
email: mfareedkhan012@gmail.com
description: >
  Muhammad Fareed — AI/ML researcher building efficient, deployable models
  (parameter-efficient fine-tuning, quantization, multimodal AI) for
  resource-constrained settings, with healthcare as a primary proving ground.
keywords: machine learning, PEFT, QLoRA, vision-language models, medical AI, NLP, deep learning
```

## URL (critical — must be exactly this for username.github.io)
```yaml
url: https://mfareedkhan.github.io
baseurl:                        # MUST be empty for a username.github.io site
```

## Social / profile links (used by the icons and Scholar bolding)
```yaml
github_username: mfareedkhan
linkedin_username: mfareedkhan012
scholar_userid: FVTRze8AAAAJ
orcid_id:                       # leave empty until you create an ORCID
```
> Note: your Google Scholar link is `...user=FVTRze8AAAAJ`; the part after `user=`
> (i.e. `FVTRze8AAAAJ`) is what goes in `scholar_userid`.

## Bold your own name in the publication list
```yaml
scholar:
  last_name: [Fareed]
  first_name: [Muhammad, M, M.]
```

## Enable project categories (needed for the Projects page grouping)
```yaml
enable_project_categories: true
```

## Blog (optional labels; the Blog section is on by default)
```yaml
blog_name: Writes
blog_description: Technical and research writing on efficient, deployable AI.
```

That's everything in the config. All other content lives in the files you'll upload.
